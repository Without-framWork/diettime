
var $ = $.noConflict();

$(document).ready(function () {

  /**
   * Main Slider
   */
  $(".silder").owlCarousel({
    items: 1,
    margin: 0,
    autoplay: false,
    autoWidth: false,
    stagePadding: 0,
    mouseDrag: false,
    loop: false,
    nav: true,
    rewind: true,
    dots: false

  });

  /**
   * Mobile Sidebar
   */

  var sides = ["left", "top", "right", "bottom"];
  $("h1 span.version").text($.fn.sidebar.version);

  // Initialize sidebars
  for (var i = 0; i < sides.length; ++i) {
    var cSide = sides[i];
    $(".mob-sidebar." + cSide).sidebar({ side: cSide });
  }

  // Click handlers
  $(".menu-btn").on("click", function () {
    var $this = $(this);
    var action = $this.attr("data-action");
    var side = $this.attr("data-side");
    $(".mob-sidebar." + side).trigger("sidebar:" + action);
    return false;
  });


  /**
   * Section Scroll
   */
  $('.cat-carousel').owlCarousel({
		loop: false,
		items:3,
    margin: 20,
    nav: false,
    autoWidth: true,
  })

  /**
   * Show More
   */
  $(".btn-prev").click(function () {
    var leftPos = $('.slider-wrap').scrollLeft();
    $(".slider-wrap").animate({ scrollLeft: leftPos - 100 }, 300);
  });

  $(".btn-next").click(function () {
    var leftPos = $('.slider-wrap').scrollLeft();
    $(".slider-wrap").animate({ scrollLeft: leftPos + 100 }, 300);
  });
});




