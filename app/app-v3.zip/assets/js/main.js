
var $ = $.noConflict();

$(document).ready(function () {



$('.main-slider').owlCarousel({
  
		rtl:true,
    items:1,
    margin:30,
		dots: true
});


});




